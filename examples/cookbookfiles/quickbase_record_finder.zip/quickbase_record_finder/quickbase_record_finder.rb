
require 'QuickBaseClient'

def find_and_display_records
  
  puts "Connecting to QuickBase..."
  qbc = QuickBase::Client.init({"username" => ARGV[0] ,"password" =>  ARGV[1],"org" => ARGV[2]})
  qbc.cacheSchemas=true
  #qbc.printRequestsAndResponses=true
  
  puts "Accessing table #{ARGV[3]}..."
  qbc.getSchema(ARGV[3])
  
  search_value = ""
  (5..ARGV.length-1).each{|index|search_value << "#{qbc.encodeXML(ARGV[index])} "}
  search_value.gsub!("'","\\'")
  search_value.strip!

  print "Searching for '#{search_value}' ...\n"
  query = ""
  field_ids = ARGV[4].split(/\./)
  field_ids.each{|fid| 
    query << "{'#{fid}'.CT.'#{search_value}'}OR" 
  }
  query.slice!(query.length-2,2)
  
  rids = qbc.getAllValuesForFieldsAsArray(ARGV[3],["3"],query,nil,nil,"3")
  
  if rids and rids.length > 0
    if rids.length > 1  
      puts "Found #{rids.length} records. Retrieving HTML page..."
      qbc.cacheSchemas=true
      html = qbc.genResultsTable(ARGV[3],query,qbc.getFieldIDs(qbc.dbid).join("."))
      puts "Creating quickbase_find_results.html..."
      File.open("quickbase_find_results.html","w"){|f|f.write(html)}
      puts "Launching quickbase_find_results.html in browser..."
      system("start quickbase_find_results.html")  
    elsif rids.length == 1 
      puts "Found one record. Displaying record for edit..."
      rid = rids[0]["3"]
      puts "Launching QuickBase in browser..."
      system("start https://www.quickbase.com/db/#{ARGV[3]}?a=er^&rid=#{rid}^&username=#{ARGV[0]}^&password=#{ARGV[1]}")
    end
  else
    puts "Found no records. Launching QuickBase 'find' page..."
    system("start https://www.quickbase.com/db/#{ARGV[3]}?a=genadvfind^&username=#{ARGV[0]}^&password=#{ARGV[1]}")
  end
end

if ARGV[5]
  begin
     find_and_display_records
  rescue StandardError => error   
     puts "\n\nAn error occurred while looking for QuickBase records: #{error}\n\n"
  end
else
  puts "\n\nUsage: quickbase_record_finder <username> <password> <realm> <table_DBID> <field_IDs> <search_value>"
  puts "\ne.g: quickbase_record_finder fred.flintone@internet.com wilma www 8emtadvk 4.5.6 barney\n\n"
end
